<?php
// created: 2023-02-09 04:56:28
$dictionary["T_nhacungcap"]["fields"]["t_nhacungcap_t_sanpham"] = array (
  'name' => 't_nhacungcap_t_sanpham',
  'type' => 'link',
  'relationship' => 't_nhacungcap_t_sanpham',
  'source' => 'non-db',
  'module' => 'T_sanpham',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_T_NHACUNGCAP_T_SANPHAM_FROM_T_SANPHAM_TITLE',
);
