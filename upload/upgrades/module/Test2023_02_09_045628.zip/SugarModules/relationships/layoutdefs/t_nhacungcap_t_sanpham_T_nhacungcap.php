<?php
 // created: 2023-02-09 04:56:28
$layout_defs["T_nhacungcap"]["subpanel_setup"]['t_nhacungcap_t_sanpham'] = array (
  'order' => 100,
  'module' => 'T_sanpham',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_T_NHACUNGCAP_T_SANPHAM_FROM_T_SANPHAM_TITLE',
  'get_subpanel_data' => 't_nhacungcap_t_sanpham',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
