<?php
// created: 2023-02-08 08:26:49
$dictionary["BT_chitietdonhang_bt"]["fields"]["bt_chitietdonhang_bt_bt_sanpham_bt"] = array (
  'name' => 'bt_chitietdonhang_bt_bt_sanpham_bt',
  'type' => 'link',
  'relationship' => 'bt_chitietdonhang_bt_bt_sanpham_bt',
  'source' => 'non-db',
  'module' => 'BT_sanpham_bt',
  'bean_name' => 'BT_sanpham_bt',
  'side' => 'right',
  'vname' => 'LBL_BT_CHITIETDONHANG_BT_BT_SANPHAM_BT_FROM_BT_SANPHAM_BT_TITLE',
);
