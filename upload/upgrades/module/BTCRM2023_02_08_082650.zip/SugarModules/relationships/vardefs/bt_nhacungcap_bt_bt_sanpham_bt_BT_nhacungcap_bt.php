<?php
// created: 2023-02-08 08:26:50
$dictionary["BT_nhacungcap_bt"]["fields"]["bt_nhacungcap_bt_bt_sanpham_bt"] = array (
  'name' => 'bt_nhacungcap_bt_bt_sanpham_bt',
  'type' => 'link',
  'relationship' => 'bt_nhacungcap_bt_bt_sanpham_bt',
  'source' => 'non-db',
  'module' => 'BT_sanpham_bt',
  'bean_name' => 'BT_sanpham_bt',
  'side' => 'right',
  'vname' => 'LBL_BT_NHACUNGCAP_BT_BT_SANPHAM_BT_FROM_BT_SANPHAM_BT_TITLE',
);
