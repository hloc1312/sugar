<?php
// created: 2023-02-08 08:26:49
$dictionary["BT_chitietdonhang_bt"]["fields"]["bt_chitietdonhang_bt_accounts"] = array (
  'name' => 'bt_chitietdonhang_bt_accounts',
  'type' => 'link',
  'relationship' => 'bt_chitietdonhang_bt_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_BT_CHITIETDONHANG_BT_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);
