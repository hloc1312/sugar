<?php
 // created: 2023-02-08 08:26:50
$layout_defs["BT_nhacungcap_bt"]["subpanel_setup"]['bt_nhacungcap_bt_bt_sanpham_bt'] = array (
  'order' => 100,
  'module' => 'BT_sanpham_bt',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_BT_NHACUNGCAP_BT_BT_SANPHAM_BT_FROM_BT_SANPHAM_BT_TITLE',
  'get_subpanel_data' => 'bt_nhacungcap_bt_bt_sanpham_bt',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
